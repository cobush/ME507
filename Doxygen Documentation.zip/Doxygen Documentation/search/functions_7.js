var searchData=
[
  ['magcalmpu9250_462',['magcalMPU9250',['../class_m_p_u9250__.html#aee35f66647f9662c8b5119aec20da770',1,'MPU9250_']]],
  ['mahonyquaternionupdate_463',['MahonyQuaternionUpdate',['../class_quaternion_filter.html#acccd0d561278e57f48a5b26ac7e54735',1,'QuaternionFilter']]],
  ['minipid_464',['MiniPID',['../class_mini_p_i_d.html#a1ca9ca279ee7fc3494089e3350819b2d',1,'MiniPID::MiniPID(double, double, double)'],['../class_mini_p_i_d.html#ad9caadb549e48f74771cd6be2b481e70',1,'MiniPID::MiniPID(double, double, double, double)']]],
  ['mpu9250_5f_465',['MPU9250_',['../class_m_p_u9250__.html#a2ff549c5319c18a69df9ccb8acad5b89',1,'MPU9250_']]]
];
