var searchData=
[
  ['baseshare_375',['BaseShare',['../class_base_share.html',1,'']]]
];
