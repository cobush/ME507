var searchData=
[
  ['direction_403',['direction',['../main_8cpp.html#a95bba0dfb42eb4ba6f55a848d6c7494a',1,'main.cpp']]],
  ['duty_5fcycle_404',['duty_cycle',['../main_8cpp.html#a2311b9ba12d685c7541e6e72181abe22',1,'main.cpp']]]
];
