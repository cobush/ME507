var searchData=
[
  ['b_5fahrs_535',['b_ahrs',['../class_m_p_u9250__.html#a56ebf42f44e348437cf0c97d1d98ca6c',1,'MPU9250_']]],
  ['b_5fverbose_536',['b_verbose',['../class_m_p_u9250__.html#a061f04164eac75ee67d6eff1b3f607de',1,'MPU9250_']]],
  ['beta_537',['beta',['../class_quaternion_filter.html#abd5ceeec025272a84597125052265710',1,'QuaternionFilter']]],
  ['buf_5fsize_538',['buf_size',['../class_queue.html#a2ede016bcaf8f330cd87f56a600218b1',1,'Queue']]]
];
