var searchData=
[
  ['reversed_595',['reversed',['../class_mini_p_i_d.html#ae165f7e6d27f6164d99481a53335b4a4',1,'MiniPID']]],
  ['roll_596',['roll',['../class_m_p_u9250__.html#a85e859f3473a25421b299e0f49e30da4',1,'MPU9250_']]]
];
