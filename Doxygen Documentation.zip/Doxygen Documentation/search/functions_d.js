var searchData=
[
  ['update_518',['update',['../class_m_p_u9250__.html#a4ad98b74ae7388b3384f35f23ae0614f',1,'MPU9250_::update()'],['../class_quaternion_filter.html#a5792ddc520c93efa4761b8b1e39c785c',1,'QuaternionFilter::update()']]],
  ['updateaccelgyro_519',['updateAccelGyro',['../class_m_p_u9250__.html#a970a249c48099623230ecfdfce6f68be',1,'MPU9250_']]],
  ['updatemag_520',['updateMag',['../class_m_p_u9250__.html#a823921a57edb57aa21bd326c95979579',1,'MPU9250_']]],
  ['updaterpy_521',['updateRPY',['../class_m_p_u9250__.html#a9ba268b2e001d3e4f35e3eeb0b18ccee',1,'MPU9250_']]],
  ['usable_522',['usable',['../class_queue.html#a2f5a7d38f857999a1c4cebe31089b0f7',1,'Queue']]]
];
