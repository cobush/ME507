var searchData=
[
  ['vertical_605',['VERTICAL',['../main_8cpp.html#a704835ed2343b7c8e5e0c7772da10738',1,'main.cpp']]]
];
