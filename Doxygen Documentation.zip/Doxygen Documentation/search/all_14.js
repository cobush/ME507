var searchData=
[
  ['verbose_353',['verbose',['../class_m_p_u9250__.html#abfc3706d294f2d8c9a89d02ad610fd48',1,'MPU9250_']]],
  ['vertical_354',['VERTICAL',['../main_8cpp.html#a704835ed2343b7c8e5e0c7772da10738',1,'main.cpp']]]
];
