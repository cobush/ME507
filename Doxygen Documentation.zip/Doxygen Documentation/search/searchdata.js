var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwxyz",
  1: "bmqs",
  2: "bmqt",
  3: "abcdgilmopqrsuvw",
  4: "abcdefghiklmnopqrstvwyz",
  5: "m",
  6: "agm",
  7: "agm",
  8: "p",
  9: "adefgilmpqstuwxyz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros"
};

