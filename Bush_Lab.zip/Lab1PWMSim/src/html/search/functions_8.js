var searchData=
[
  ['setup_72',['setup',['../main_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'main.cpp']]],
  ['share_73',['Share',['../class_share.html#a0948b04d00aef072f25af2f49ecfa259',1,'Share']]]
];
