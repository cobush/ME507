var searchData=
[
  ['task_5fsim_34',['task_sim',['../main_8cpp.html#aedae232608142fbbd4ece4cfe363e74c',1,'main.cpp']]],
  ['task_5fui_35',['task_ui',['../main_8cpp.html#aeca539d059d1b76b873ccdadf74ca23d',1,'main.cpp']]],
  ['taskqueue_2eh_36',['taskqueue.h',['../taskqueue_8h.html',1,'']]],
  ['taskshare_2eh_37',['taskshare.h',['../taskshare_8h.html',1,'']]],
  ['the_5fdata_38',['the_data',['../class_share.html#a7247d922017c7720e3c2146a9d286be6',1,'Share']]],
  ['ticks_5fto_5fwait_39',['ticks_to_wait',['../class_queue.html#ac7869eacf6bc024b4d8ce25496fdaaed',1,'Queue']]]
];
