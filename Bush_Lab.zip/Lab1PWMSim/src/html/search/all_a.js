var searchData=
[
  ['queue_31',['Queue',['../class_queue.html',1,'Queue&lt; dataType &gt;'],['../class_queue.html#ae4a3fd660457ea5f5a4f3605322db150',1,'Queue::Queue()']]]
];
