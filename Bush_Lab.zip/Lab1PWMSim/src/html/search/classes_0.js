var searchData=
[
  ['baseshare_41',['BaseShare',['../class_base_share.html',1,'']]]
];
