var searchData=
[
  ['operator_2b_2b_22',['operator++',['../class_share.html#af06e2b1c56e997767bc4b42129cc1a15',1,'Share::operator++(void)'],['../class_share.html#aa25e220e5ddcc6c162afbda754ab3929',1,'Share::operator++(int)']]],
  ['operator_2d_2d_23',['operator--',['../class_share.html#a423167619b7e994a18cefb795b31ffda',1,'Share::operator--(void)'],['../class_share.html#a802c6d21fd219e25122f6b93f92ab407',1,'Share::operator--(int)']]]
];
