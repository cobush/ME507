var searchData=
[
  ['buf_5fsize_77',['buf_size',['../class_queue.html#a2ede016bcaf8f330cd87f56a600218b1',1,'Queue']]]
];
