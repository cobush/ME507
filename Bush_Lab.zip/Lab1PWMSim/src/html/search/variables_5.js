var searchData=
[
  ['the_5fdata_83',['the_data',['../class_share.html#a7247d922017c7720e3c2146a9d286be6',1,'Share']]],
  ['ticks_5fto_5fwait_84',['ticks_to_wait',['../class_queue.html#ac7869eacf6bc024b4d8ce25496fdaaed',1,'Queue']]]
];
