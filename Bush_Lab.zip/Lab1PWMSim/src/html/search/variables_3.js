var searchData=
[
  ['name_80',['name',['../class_base_share.html#abc438f82d56097f13a1e791dcd617a72',1,'BaseShare']]]
];
