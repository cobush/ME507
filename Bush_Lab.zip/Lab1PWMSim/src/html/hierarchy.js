var hierarchy =
[
    [ "BaseShare", "class_base_share.html", [
      [ "Queue< dataType >", "class_queue.html", null ],
      [ "Share< DataType >", "class_share.html", null ]
    ] ]
];