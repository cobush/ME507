var files_dup =
[
    [ "baseshare.cpp", "baseshare_8cpp.html", "baseshare_8cpp" ],
    [ "baseshare.h", "baseshare_8h.html", "baseshare_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "taskqueue.h", "taskqueue_8h.html", [
      [ "Queue", "class_queue.html", "class_queue" ]
    ] ],
    [ "taskshare.h", "taskshare_8h.html", [
      [ "Share", "class_share.html", "class_share" ]
    ] ]
];