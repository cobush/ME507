var main_8cpp =
[
    [ "loop", "main_8cpp.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "parseIntWithEcho", "main_8cpp.html#a83e2559905ce06de071389dfb6ea3b97", null ],
    [ "setup", "main_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "task_sim", "main_8cpp.html#aedae232608142fbbd4ece4cfe363e74c", null ],
    [ "task_ui", "main_8cpp.html#aeca539d059d1b76b873ccdadf74ca23d", null ],
    [ "duty_cycle", "main_8cpp.html#a0d755a47b31dfe34438194d3286599cc", null ]
];